import "./About.css";

export function About(): JSX.Element {
    return (
        <div className="About">
			<h1>About Me</h1>
        </div>
    );
}
