import "./Contact.css";

export function Contact(): JSX.Element {
    return (
        <div className="Contact">
			<h2>Contact Me</h2>
        </div>
    );
}
