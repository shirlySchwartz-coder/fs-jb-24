to do

npm install -g create-react-app

create-react-app react-is-easy --template typescript

windows error:
open power shell as administrator
run the command : set-executionpolicy remotesigned

npm install -g react-cli-snippets

vs-code extenstion:
auto import
spell checker


to add component
create fc [folder]/[name]

to add component with props
create fc [folder]/[name] --props
insert fields that you require to interface