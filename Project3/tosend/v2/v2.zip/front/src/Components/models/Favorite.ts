export class Favorite {
  public idVacation: number;
  constructor(idVacation: number) {
    this.idVacation = idVacation;
  }
}
