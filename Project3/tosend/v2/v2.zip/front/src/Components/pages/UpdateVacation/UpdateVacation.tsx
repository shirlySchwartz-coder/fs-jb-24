import "./UpdateVacation.css";

export function UpdateVacation(): JSX.Element {
    return (
        <div className="UpdateVacation">
			<h2>Update Vacation</h2>
        </div>
    );
}
