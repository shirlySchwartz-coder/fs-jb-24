import "./Footer.css";

export function Footer(): JSX.Element {
    return (
        <div className="Footer">
			Footer
        </div>
    );
}
