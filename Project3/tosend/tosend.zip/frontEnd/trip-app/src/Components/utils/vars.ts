class Vars{
    public allVacationsUrl =`http://localhost:8080/api/v1/vacations/all`;
}

const pathUrl =new Vars()
export default pathUrl