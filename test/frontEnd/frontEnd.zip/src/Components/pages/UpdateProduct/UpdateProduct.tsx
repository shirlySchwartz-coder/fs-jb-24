import "./UpdateProduct.css";

export function UpdateProduct(): JSX.Element {
    return (
        <div className="UpdateProduct">
			<h1>Update Products</h1><hr/>
        </div>
    );
}
