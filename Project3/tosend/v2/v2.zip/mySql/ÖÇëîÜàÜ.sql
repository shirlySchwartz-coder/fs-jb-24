INSERT INTO  tagging_vacation.followers(idFollower,idVacation) 
    VALUES (2,3)
    
    --
    SELECT * FROM tagging_vacation.followers Where idFollower=2;