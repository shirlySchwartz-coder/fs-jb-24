import "./MainFooter.css";

function MainFooter(): JSX.Element {
    return (
        <div className="MainFooter">
			all rights reserved to Wolf mother in law 666 (c)
        </div>
    );
}

export default MainFooter;
