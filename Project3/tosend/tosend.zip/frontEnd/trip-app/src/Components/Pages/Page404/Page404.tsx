import "./Page404.css";

export function Page404(): JSX.Element {
    return (
        <div className="Page404">
			Page not found 
        </div>
    );
}
