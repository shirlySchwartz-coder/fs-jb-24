import "./Footer.css";

export function Footer(): JSX.Element {
    return (
        <div className="Footer">
			<h3>footer</h3>
        </div>
    );
}
